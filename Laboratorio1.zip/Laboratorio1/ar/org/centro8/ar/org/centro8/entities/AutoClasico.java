package ar.org.centro8.entities;

public class AutoClasico extends Vehiculo {

    private Radio radio;

    public AutoClasico(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio);
        this.radio = radio;
    }

    public void agregarRadio(Radio radio) {
        this.radio = radio;
    }

    public Radio cambiarRadio(Radio nuevaRadio) {
        Radio radioAnterior = this.radio;
        this.radio = nuevaRadio;
        return radioAnterior;
    }

    @Override
    public String toString() {
        return super.toString() + ", con radio marca " + radio.getMarca();
    }

    public static void agregarRadio(int i) {
    }

}