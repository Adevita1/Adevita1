package ar.org.centro8.entities;

public abstract class Vehiculo{

    private String marca;
    private String modelo;
    private String color;
    private double precio;

    public Vehiculo(String marca, String modelo, String color, double precio){
        this.marca= marca;
        this.modelo= modelo;
        this.color= color;
        this.precio= precio;
        
    }

    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio + "]";
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public double getPrecio() {
        return precio;
    }
    



}