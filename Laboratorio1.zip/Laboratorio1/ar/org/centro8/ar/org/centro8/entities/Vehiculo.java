package ar.org.centro8.entities;

public abstract class Vehiculo{

    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color, double precio, String marcaRadio, String potencia){
        this.marca= marca;
        this.modelo= modelo;
        this.color= color;
        this.precio= precio;
        this.radio= new Radio(marcaRadio, potencia);
        
    }
    
    
    public Vehiculo(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    
    }


    public Vehiculo(String marca, String modelo, String color, String marcaRadio, String potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio= new Radio(marcaRadio, potencia);
    }

        public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }


    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", radio=" + radio + "]";
    }





    public String getMarca() {
        return marca;
    }





    public void setMarca(String marca) {
        this.marca = marca;
    }





    public String getModelo() {
        return modelo;
    }





    public void setModelo(String modelo) {
        this.modelo = modelo;
    }





    public String getColor() {
        return color;
    }





    public void setColor(String color) {
        this.color = color;
    }





    public double getPrecio() {
        return precio;
    }





    public void setPrecio(double precio) {
        this.precio = precio;
    }





    public Radio getRadio() {
        return radio;
    }





    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    public void ingresarRadio( String Marca, double potencia){

    }

    public void cambiarRadio( String Marca, double potencia){

    }

    public void sinPrecio(String sinPrecio){

    }
}