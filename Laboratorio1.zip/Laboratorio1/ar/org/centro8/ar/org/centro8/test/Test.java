package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;


public class Test {
    public static void main(String[] args) {

        AutoClasico auto1 =new AutoClasico(null, null, null, 0, null, null, null);
        System.out.println(auto1);
        auto1.ingresarRadio("chuco", 11);
        System.out.println(auto1);
        auto1.cambiarRadio("cholo", 12);
        System.out.println(auto1);
        
        AutoNuevo auto2 =new AutoNuevo(null, null, null, 0, null, null);
        System.out.println(auto2);
        auto2.cambiarRadio("nulo", 0);
        System.out.println(auto2);
        System.out.println(auto2);

        Colectivo colectivo1 =new Colectivo(null, null, null, 0, null, null, null);
        System.out.println(colectivo1);
        colectivo1.cambiarRadio("turu", 0);
        System.out.println(colectivo1);

        Colectivo colectivo2 =new Colectivo(null, null, null, null);
        System.out.println(colectivo2);
        colectivo2.cambiarRadio("chucu", 0);
        System.out.println(colectivo2);

}
}