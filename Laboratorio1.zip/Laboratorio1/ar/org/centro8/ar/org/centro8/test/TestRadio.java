package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;


public class TestRadio {
    public static void main(String[] args) {

        System.out.println("-- radio1 --");
        AutoClasico auto1 =new AutoClasico(null, null, null, 0, null, null, null);

        System.out.println(auto1);
        System.out.println("-- auto2 --");
        AutoNuevo auto2 =new AutoNuevo(null, null, null, 0, null, null);
        System.out.println(auto2);
        System.out.println("-- colectivo1 --");
        Colectivo colectivo1 =new Colectivo(null, null, null, 0, null, null, null);
        System.out.println(colectivo1);

        auto1.ingresarRadio("null", 12);
        auto2.cambiarRadio("null", 23);
        colectivo1.ingresarRadio(null, 0);

        Coletivo colectivo2 =new Colectivo(null, null, null, 0, null, null, null);
        AutoClasico auto3 =new AutoClasico(null, null, null, 0, null, null, null);
        AutoNuevo auto4 =new AutoNuevo(null, null, null, 0, null, null);


}
}