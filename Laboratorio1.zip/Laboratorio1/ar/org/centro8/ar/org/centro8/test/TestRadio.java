package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;


public class TestRadio {
    public static void main(String[] args) {

        System.out.println("-- autoClasico1 --");
        AutoClasico autoClasico1 =new AutoClasico(null, null, null, 0, null, null, null);
        System.out.println(autoClasico1);
        
        System.out.println("-- autoClasico2 --");
        AutoClasico autoClasico2 =new AutoClasico(null, null, null, 0, null, null, null);
        System.out.println(autoClasico2);

        System.out.println("-- autoClasico3 --");
        AutoClasico autoClasico3 =new AutoClasico(null, null, null, 0, null, null, null);
        System.out.println(autoClasico3);
        
        System.out.println("-- autoClasico4 --");
        AutoClasico autoClasico4 =new AutoClasico(null, null, null, 0, null, null, null);
        System.out.println(autoClasico4);

        System.out.println("-- autoNuevo1 --");
        AutoNuevo autoNuevo1 =new AutoNuevo(null, null, null, 0, null, null);
        System.out.println(autoNuevo1);

        System.out.println("-- autoNuevo2 --");
        AutoNuevo autoNuevo2 =new AutoNuevo(null, null, null, 0, null, null);
        System.out.println(autoNuevo2);

        System.out.println("-- autoNuevo3 --");
        AutoNuevo autoNuevo3 =new AutoNuevo(null, null, null, 0, null, null);
        System.out.println(autoNuevo3);

        System.out.println("-- autoNuevo4 --");
        AutoNuevo autoNuevo4 =new AutoNuevo(null, null, null, 0, null, null);
        System.out.println(autoNuevo4);

        System.out.println(" -- colectivo1 --");
        Colectivo colectivo1 =new Colectivo(null, null, null, 0, null, null, null);
        System.out.println(colectivo1);

        System.out.println(" -- colectivo2 --");
        Colectivo colectivo2 =new Colectivo(null, null, null, 0, null, null, null);
        System.out.println(colectivo2);

        System.out.println(" -- colectivo3 --");
        Colectivo colectivo3 =new Colectivo(null, null, null, 0, null, null, null);
        System.out.println(colectivo3);

        System.out.println(" -- colectivo4 --");
        Colectivo colectivo4 =new Colectivo(null, null, null, 0, null, null, null);
        System.out.println(colectivo4);

        
}
}