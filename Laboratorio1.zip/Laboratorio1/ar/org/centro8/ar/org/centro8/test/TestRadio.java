package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;


public class TestRadio {
    public static void main(String[] args) {

        System.out.println("-- radio1 --");
        AutoClasico.agregarRadio(40000);
        AutoNuevo.cambiarRadio(40000);
        Colectivo.agregarRadio();
       
}
}