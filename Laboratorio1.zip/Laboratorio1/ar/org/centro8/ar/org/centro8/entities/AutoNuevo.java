package ar.org.centro8.entities;

public class AutoNuevo extends Vehiculo {
    private Radio radio;

    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaRadio, String potencia) {
        super(marca, modelo, color, precio, marcaRadio, potencia);
    }

    

    


    
    
}
