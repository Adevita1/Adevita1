package ar.org.centro8.entities;

public class AutoNuevo extends Vehiculo {
    private Radio radio;

    public AutoNuevo(String marca, String modelo, String color, double precio, String mRadio, String potencia) {
        super(marca, modelo, color, precio, mRadio, potencia);
    }

    

    

    


    
    
}
