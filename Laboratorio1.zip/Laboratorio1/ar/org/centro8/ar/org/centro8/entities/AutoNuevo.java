package ar.org.centro8.entities;

public class AutoNuevo extends Vehiculo {
    private Radio radio;

    public AutoNuevo(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio);
        this.radio = radio;
    }

    public Radio cambiarRadio(Radio nuevaRadio){
        Radio radioAnterior= this.radio;
        this.radio= nuevaRadio;
        return radioAnterior;
    }

    public String toString() {
        return super.toString() +",con marca" +radio.getMarca();
    }

    public static void cambiarRadio(int i) {
    }

    
    
}
