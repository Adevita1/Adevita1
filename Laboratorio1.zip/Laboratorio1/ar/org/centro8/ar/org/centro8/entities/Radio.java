package ar.org.centro8.entities;

public class Radio {

    private String mRadio;
    private Double potencia;

    
    

    


    public Radio(String mRadio, Double potencia) {
        this.mRadio = mRadio;
        this.potencia = potencia;
    }







    @Override
    public String toString() {
        return "Radio [mRadio=" + mRadio + ", potencia=" + potencia + "]";
    }







    public String getmRadio() {
        return mRadio;
    }







    public void setmRadio(String mRadio) {
        this.mRadio = mRadio;
    }







    public Double getPotencia() {
        return potencia;
    }







    public void setPotencia(Double potencia) {
        this.potencia = potencia;
    }

    
    
    
    

}
