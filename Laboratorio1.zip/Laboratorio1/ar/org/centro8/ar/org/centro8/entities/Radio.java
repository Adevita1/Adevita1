package ar.org.centro8.entities;

public class Radio {

    private String marca;
    private Double potencia;
    

    public Radio(String marca, double potencia){
        this.marca= marca;
        this.potencia= potencia;
    }



    public Radio(int i, String string) {
    }



    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }

    public String getMarca() {
        return marca;
    }

    public Double getPotencia() {
        return potencia;
    }
    

}
