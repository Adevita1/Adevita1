package ar.org.centro8.entities;

public class Radio {

    private String marca;
    private Double potencia;
    

    public Radio(String marca, Double potencia2){
        this.marca= marca;
        this.potencia= potencia2;
    }



    public Radio(int i, String string) {
    }



    public Radio(String marcaRadio, String potencia2) {
    }



    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }



    public String getMarca() {
        return marca;
    }



    public void setMarca(String marca) {
        this.marca = marca;
    }



    public Double getPotencia() {
        return potencia;
    }



    public void setPotencia(Double potencia) {
        this.potencia = potencia;
    }

    

}
