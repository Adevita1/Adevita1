package ar.org.centro8.entities;

public class Colectivo extends Vehiculo{
    private Radio radio;

    public Colectivo(String marca, String modelo, String color, double precio, String mRadio, String potencia,
            Radio radio) {
        super(marca, modelo, color, precio, mRadio, potencia);
        this.radio = radio;
    }

    public Colectivo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color);
        this.radio = radio;
    }
    

    

    

    
}
