package ar.org.centro8.entities;

public class Colectivo extends Vehiculo{
    private Radio radio;

    public Colectivo(String marca, String modelo, String color, double precio, String marcaRadio, String potencia,
            Radio radio) {
        super(marca, modelo, color, precio, marcaRadio, potencia);
        this.radio = radio;
    }

    

    

    
}
