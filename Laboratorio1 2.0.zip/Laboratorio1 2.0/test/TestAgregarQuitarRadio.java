package test;

import entities.AutoClasico;
import entities.AutoNuevo;
import entities.Colectivo;
import entities.Radio;
import entities.Vehiculo;

public class TestAgregarQuitarRadio {
    public static void main(String[] args) {

        Vehiculo auto1 = new AutoClasico("Chevrolet", "Corsa", "azul", 34, null);
        Vehiculo auto2 = new AutoNuevo("Renault", "Duster", "blanco", 45, null);
        Vehiculo colectivo1 = new Colectivo("Peugeot", "206", "gris", 45, null);

        Radio radio1 = new Radio("Sony", 8.0);
        Radio radio2 = new Radio("Pioneer", 12.0);
        Radio radio3 = new Radio("JBL", 10.0);

        ((AutoClasico) auto1).agregarRadio(radio1);
        ((AutoNuevo) auto2).cambiarRadio(radio2);
        ((Colectivo) colectivo1).agregarRadio(radio3);
        ((Colectivo) colectivo1).cambiarRadio(radio2);

        System.out.println(auto1);
        System.out.println(auto2);
        System.out.println(colectivo1);
    }
}