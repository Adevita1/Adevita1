package entities;

public abstract class Vehiculo{

    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private String Radio;

   
    public Vehiculo(String marca, String modelo, String color, double precio, String radio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        Radio = radio;
    }


    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", Radio=" + Radio + "]";
    }


    public String getMarca() {
        return marca;
    }


    public String getModelo() {
        return modelo;
    }


    public String getColor() {
        return color;
    }


    public double getPrecio() {
        return precio;
    }


    public String getRadio() {
        return Radio;
    }
    
    



}