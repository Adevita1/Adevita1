package entities;

public class Radio{

    String marca;
    Double potencia;


    public Radio(String marca, double potencia){
        this.marca= marca;
        this.potencia= potencia;
    }

    public void agregarRadio (){
        marca= "Sony";
        potencia= 10.0;
    }

    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }

    public String getMarca() {
        return null;
    }

    

}
