package entities;

public class Colectivo extends Vehiculo{
    

    private entities.Radio radio;

    public Colectivo(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio, color);
        this.radio = radio;
    }

    public void agregarRadio(Radio radio){
        this.radio = radio;
    }

    public Radio cambiarRadio(Radio nuevaRadio){
        Radio radioAnterior = this.radio;
        this.radio = nuevaRadio;
        return radioAnterior;
    }

    @Override
    public String toString() {
        return "Colectivo [radio=" + radio + "]";
    }
}
